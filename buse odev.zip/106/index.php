<?php include 'inc/head.php';?>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">
               <span class="spinner-rotate"></span>
          </div>
     </section>

<?php include 'inc/menu.php';?>

     <!-- HOME -->
     <section id="ANASAYFA">
          <div class="row">
               <div class="owl-carousel owl-theme home-slider">
                    <div class="item item-first">
                         <div class="caption">
                              <div class="container">
                                   <div class="col-md-6 col-sm-12">
                                        <h1>UYGUNA ARABA İÇİN DOĞRU ADRESTESİNİZ.</h1>
                                    
                                        <a href="fleet.php" class="section-btn btn btn-default">KİRALIK ARABALARIMIZ</Kbd></a>
                                   </div>
                              </div>
                         </div>
                    </div>

                    <div class="item item-second">
                         <div class="caption">
                              <div class="container">
                                   <div class="col-md-6 col-sm-12">
                                        <h1>UYGUNA ARABA İÇİN DOĞRU ADRESTESİNİZ.</h1>
                                     
                                        <a href="fleet.php" class="section-btn btn btn-default">KİRALIK ARABALARIMIZ</a>
                                   </div>
                              </div>
                         </div>
                    </div>

                    <div class="item item-third">
                         <div class="caption">
                              <div class="container">
                                   <div class="col-md-6 col-sm-12">
                                        <h1>UYGUNA ARABA İÇİN DOĞRU ADRESTESİNİZ </h1>
                                    
                                        <a href="fleet.php" class="section-btn btn btn-default">KİRALIK ARABALARIMIZ</a>
                                   </div>
                              </div>
                         </div>
                    </div>
               </div>
          </div>
     </section>

     <main>
          <section>
               <div class="container">
                    <div class="row">
                         <div class="col-md-12 col-sm-12">
                              <div class="text-center">
                                   <h2>HAKKIMIZDA</h2>

                                   <br>

                                   <p class="lead">.Arabalarla ilgili her şey için nihai varış noktanız olan BUSE ARABACILIK'a 
                                        hoş geldiniz. Biz, otomobil tutkunlarına otomobil satın alma ve satma yolculuklarında 
                                         ve rahat bir deneyim sunmaya adanmış birinci sınıf bir çevrimiçi platformuz.
                                        BUSE ARABACILIK'da, bir araba sahibi olmanın getirdiği heyecan ve tutkuyu anlıyoruz. İster yepyeni 
                                        bir araç, ister güvenilir bir kullanılmış araba arıyor olun, ister sadece uzman tavsiyesi ve
                                         bilgisi arıyor olun, size yardımcı oluyoruz</p>
                              </div>
                         </div>
                    </div>
               </div>
          </section>

          <section>
               <div class="container">
                    <div class="row">
                         <div class="col-md-12 col-sm-12">
                              <div class="section-title text-center">
                                   <h2>İNDİRİMLİ ARABALARIMIZ <small>İndirimli araçlarımızdan bir kaç tanesi burada bulunmaktadır.</small></h2>
                              </div>
                         </div>

                         <div class="col-md-4 col-sm-6">
                              <div class="team-thumb">
                                   <div class="team-image">
                                        <img src="assets/images/buse 6767.jpg" class="img-responsive" alt="">
                                   </div>
                                   <div class="team-info">
                                        <h3>AUDİ</h3>

                                        <p class="lead"><small></small> <strong>700LİRADAN BAŞLAYAN FİYATLARLA</strong> </p>

                                        <span>Siz tatilin tadını çıkarırken biz size konfor sağlıyoruz. İndirimli araçlarımızdan yararlanmak için elinizi hızlı tutun</span>
                                   </div>
                                   <div class="team-thumb-actions">
                                        <a href="offers.php" class="section-btn btn btn-primary btn-block">TIKLAYINIZ</a>
                                   </div>
                              </div>
                         </div>

                         <div class="col-md-4 col-sm-6">
                             <div class="team-thumb">
                                   <div class="team-image">
                                        <img src="assets/images/2023-yeni-toyota-corolla-sedan-turkiye-1.jpg" class="img-responsive" alt="">
                                   </div>
                                   <div class="team-info">
                                        <h3>TOYOTA</h3>

                                        <p class="lead"><small></small> <strong>800 LİRADAN BAŞLAYAN FİYATLARLA</strong></p>

                                        <span>Siz tatilin tadını çıkarırken biz size konfor sağlıyoruz. İndirimli araçlarımızdan yararlanmak için elinizi hızlı tutun</span>
                                   </div>
                                   <div class="team-thumb-actions">
                                        <a href="offers.php" class="section-btn btn btn-primary btn-block">TIKLAYINIZ</a>
                                   </div>
                              </div>
                         </div>

                         <div class="col-md-4 col-sm-6">
                              <div class="team-thumb">
                                   <div class="team-image">
                                        <img src="assets/images/indir.jpg" class="img-responsive" alt="">
                                   </div>
                                   <div class="team-info">
                                        <h3>DACİA</h3>

                                        <p class="lead"><small></small> <strong>1000 LİRADAN BAŞLAYAN FİYATLARLA</strong> </p>

                                        <span>Siz tatilin tadını çıkarırken biz size konfor sağlıyoruz. İndirimli araçlarımızdan yararlanmak için elinizi hızlı tutun</span>
                                   </div>
                                   <div class="team-thumb-actions">
                                        <a href="offers.php" class="section-btn btn btn-primary btn-block">TIKLAYINIZ</a>
                                   </div>
                              </div>
                         </div>
                    </div>
               </div>
          </section>
          
          <section id="testimonial">
               <div class="container">
                    <div class="row">

                         <div class="col-md-12 col-sm-12">
                              <div class="section-title text-center">
                                   <h2>SİZİN GÖRÜŞLERİNİZ <small>Siz değerli müşterilerimizin görüşleri</small></h2>
                              </div>

                              <div class="owl-carousel owl-theme owl-client">
                                   <div class="col-md-4 col-sm-4">
                                        <div class="item">
                                             <div class="tst-image">
                                                  <img src="assets/images/vesikalık-fotoğraf-nasıl-yapılır-5.jpg" class="img-responsive" alt="">
                                             </div>
                                             <div class="tst-author">
                                                  <h4>SELİM</h4>
                                                  <span>Yazılım geliştirici</span>
                                             </div>
                                             <p>Diğer sitelerde ayıran bir diğer özellik ise herkes ile tek tek ilgeniyorlar</p>
                                             <div class="tst-rating">
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                             </div>
                                        </div>
                                   </div>

                                   <div class="col-md-4 col-sm-4">
                                        <div class="item">
                                             <div class="tst-image">
                                                  <img src="assets/images/pasaport.jpg" class="img-responsive" alt="">
                                             </div>
                                             <div class="tst-author">
                                                  <h4>VEFA</h4>
                                                  <span>Avukat</span>
                                             </div>
                                             <p>Memun kaldım tek sıkıntı biraz pahalı.</p>
                                             <div class="tst-rating">
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                             </div>
                                        </div>
                                   </div>

                                   <div class="col-md-4 col-sm-4">
                                        <div class="item">
                                             <div class="tst-image">
                                                  <img src="assets/images/biyometrikkkkk.jpg" class="img-responsive" alt="">
                                             </div>
                                             <div class="tst-author">
                                                  <h4>SERPİL </h4>
                                                  <span>Hemşire</span>
                                             </div>
                                             <p>Genç girişimcilerden oluşan oluşan bir ekip çok memnun kaldım.</p>
                                             <div class="tst-rating">
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>

                                             </div>
                                        </div>
                                   </div>

                                   <div class="col-md-4 col-sm-4">
                                        <div class="item">
                                             <div class="tst-image">
                                                  <img src="assets/images/canan.jpg" class="img-responsive" alt="">
                                             </div>
                                             <div class="tst-author">
                                                  <h4>Canan</h4>
                                                  <span>Mühendis</span>
                                             </div>
                                             <p>Memnun kaldım çevreme tavsiye edicem.</p>
                                             <div class="tst-rating">
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                             </div>
                                        </div>
                                   </div>

                              </div>
                        </div>
                    </div>
               </div>
          </section> 
     </main>

     <!-- CONTACT -->
     <section id="contact">
          <div class="container">
               <div class="row">

                    <div class="col-md-6 col-sm-12">
                         <form id="contact-form" role="form" action="" method="post">
                              <div class="section-title">
                                   <h2>BİZE ULAŞIN <small>Müşteri memnuniyeti [BUSE ARABACILIK] için en öncelikli
 amaç.en iyi hizmeti sunmak için buradayız ve her türlü soru, öneri veya şikayetinizi 
         memnuniyetle dinleyemeyeceğimizi tüketmemizi istiyor.  Eğer herhangi bir konuda yardıma ihtiyacınız varsa, aşağıdaki iletişim bilgilerini
                                         kullanarak bize ulaşabilirsiniz:</small></h2>
                              </div>

                              <div class="col-md-12 col-sm-12">
                                   <input type="text" class="form-control" placeholder="AD SOYAD " name="name" required>
                    
                                   <input type="email" class="form-control" placeholder="MAİL ADRESİNİZ" name="email" required>

                                   <textarea class="form-control" rows="6" placeholder="MESAJINIZI YAZINIZ" name="message" required></textarea>
                              </div>

                              <div class="col-md-4 col-sm-12">
                                   <input type="submit" class="form-control" name="send message" value="MESAJINIZI GÖNDERİN">
                              </div>

                         </form>
                    </div>

                    <div class="col-md-6 col-sm-12">
                         <div class="contact-image">
                              <img src="assets/images/Adsiz-400-×-600-piksel-600-×-400-piksel.png" class="img-responsive" alt="Smiling Two Girls">
                         </div>
                    </div>

               </div>
          </div>
     </section>       
<?php include 'inc/footer.php';?>
<?php include 'inc/js.php';?>
</body>
</html>