<?php include 'inc/head.php';?>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>
               
          </div>
     </section>

<?php include 'inc/menu.php';?>

     <section>
          <div class="container">
               <div class="text-center">
                    <h1>TAKIM</h1>

                    <br>

                    <p class="lead"> BU SAYFA ÇALIŞMA ARKAŞLARIMIZI İÇERİR</p>
               </div>
          </div>
     </section>

     <section id="team" class="section-background">
          <div class="container">
               <div class="row">
                    <div class="col-md-3 col-sm-6">
                         <div class="team-thumb">
                              <div class="team-image">
                                   <img src="assets/images/biyometrik.jpg" class="img-responsive" alt="">
                              </div>
                              <div class="team-info">
                                   <h3>BUSE </h3>
                                   <span>MÜDÜR</span>
                              </div>
                              <ul class="social-icon">
                         
                                   <li><a href="https://twitter.com/" class="fa fa-twitter"></a></li>
                                   <li><a href="https://www.instagram.com/" class="fa fa-instagram"></a></li>
                              </ul>
                         </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                         <div class="team-thumb">
                              <div class="team-image">
                                   <img src="assets/images/erkek.jpg" class="img-responsive" alt="">
                              </div>
                              <div class="team-info">
                                   <h3>CAN</h3>
                                   <span>SATIŞ ELEMANI</span>
                              </div>
                              <ul class="social-icon">
                                   <li><a href="https://google.com/" class="fa fa-google"></a></li>
                                   <li><a href="https://instagram.com/" class="fa fa-instagram"></a></li>
                              </ul>
                         </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                         <div class="team-thumb">
                              <div class="team-image">
                                   <img src="assets/images/veslıkkk.jpg" class="img-responsive" alt="">
                              </div>
                              <div class="team-info">
                                   <h3>BEKİR</h3>
                                   <span>SATIŞ ELEMANI</span>
                              </div>
                              <ul class="social-icon">
                                   <li><a href="https://twitter.com/" class="fa fa-twitter"></a></li>
                                   <li><a href="https://linkedin.com/" class="fa fa-linkedin"></a></li>
                              </ul>
                         </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                         <div class="team-thumb">
                              <div class="team-image">
                                   <img src="assets/images/images.jpg" class="img-responsive" alt="">
                              </div>
                              <div class="team-info">
                                   <h3>EDA</h3>
                                   <span>MÜŞTERİ TEMSİLCİSİ</span>
                              </div>
                              <ul class="social-icon">
                                   <li><a href="https://twitter.com/" class="fa fa-twitter"></a></li>
                                   <li><a href="https://google.com/" class="fa fa-google"></a></li>
                              </ul>
                         </div>
                    </div>
               </div>
          </div>
          </section>

          <?php include 'inc/footer.php';?>

          <div class="modal fade bs-example-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
               <div class="modal-dialog" role="document">
                    <div class="modal-content">
                         <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                              <h4 class="modal-title" id="gridSystemModalLabel">REZERVASYON YAP</h4>
                         </div>
                         
                         <div class="modal-body">
                              <form action="#" id="contact-form">
                                   <div class="row">
                                        <div class="col-md-6">
                                             <input type="text" class="form-control" placeholder="TESLİM ALINACAK YER" required>
                                        </div>
     
                                        <div class="col-md-6">
                                             <input type="text" class="form-control" placeholder="TESLİM EDİLECEK YER " required>
                                        </div>
                                   </div>
     
                                   <div class="row">
                                        <div class="col-md-6">
                                             <input type="text" class="form-control" placeholder="ALIŞ TARİHİ" required>
                                        </div>
     
                                        <div class="col-md-6">
                                             <input type="text" class="form-control" placeholder="VERİŞ TARİHİ" required>
                                        </div>
                                   </div>
                                   <input type="text" class="form-control" placeholder="AD SOYAD" required>
     
                                   <div class="row">
                                        <div class="col-md-6">
                                             <input type="text" class="form-control" placeholder="MAİLİNİZİ YAZINIZ" required>
                                        </div>
     
                                        <div class="col-md-6">
                                             <input type="text" class="form-control" placeholder="TELEFON NUMARANIZI YAZINIZ" required>
                                        </div>
                                   </div>
                              </form>
                         </div>
     
                         <div class="modal-footer">
                              <button type="button" class="section-btn btn btn-primary">REZERVASYON YAP</button>
                         </div>
                    </div>
               </div>
          </div>
     <?php include 'inc/js.php';?>

</body>
</html>