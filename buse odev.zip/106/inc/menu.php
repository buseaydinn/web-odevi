
     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="#" class="navbar-brand">BUSE ARABACILIK</a>
               </div>

               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-nav-first">
                         <li class="active"><a href="index.php">ANASAYFA </a></li>
                         <li><a href="fleet.php">KİRALIK ARABALARIMIZ</a></li>
                         <li><a href="offers.php">İNDİRİMLİ ARABALARIMIZ</a></li>
                         <li class="HAKKIMIZDA">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">HAKKIMIZDA<span class="caret"></span></a>
                              
                              <ul class="dropdown-menu">
                              
                                   <li><a href="about-us.php">HAKKIMIZDA</a></li>
                                   <li><a href="team.php">TAKIM</a></li>
                                   <li><a href="testimonials.php">SİZİN GÖRÜŞLERİNİZ</a></li>
                                   <li><a href="terms.php">ŞARTLAR</a></li>
                              </ul>
                         </li>
                         <li><a href="contact.php">BİZE ULAŞIN</a></li>
                    </ul>
               </div>

          </div>
     </section>