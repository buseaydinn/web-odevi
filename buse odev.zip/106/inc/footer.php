     <!-- FOOTER -->
     <footer id="footer">
          <div class="container">
               <div class="row">

                    <div class="col-md-4 col-sm-6">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>ADRESİMİZ</h2>
                              </div>
                              <address>
                                   <p>DÜZCE MERKEZ DARICI MAHASLLESİ MÜEZZİN SOKKAK NO 20 </p>
                              </address>

                              <ul class="social-icon">
                                 
                                   <li><a href="https://twitter.com/" class="fa fa-twitter"></a></li>
                                   <li><a href="https://www.instagram.com/" class="fa fa-instagram"></a></li>
                              </ul>

                              <div class=""Bir araba sadece bir makine değil, bir tutkudur."> 
                                   <p>ARABA SADECE BİR MAKİNE DEĞİL TUTKUDUR</p>
                                   
                              </div>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>İLETİŞİM </h2>
                              </div>
                              <address>
                                   <p>0536 382 7881</p>
                                   <p><a href="mailto:contact@company.com">buseecan81@gmail.com</a></p>
                              </address>

                              <div class="footer_menu">
                                   <h2>SİTE LİNKLERİ</h2>
                                   <ul>
                                        <li><a href="index.php">ANASAYFA</a></li>
                                        <li><a href="about-us.php">HAKKIMIZDA</a></li>
                                        <li><a href="terms.php">ŞARTLAR</a></li>
                                       
                                   </ul>
                              </div>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-12">
                         <div class="footer-info newsletter-form">
                              <div class="section-title">
                                   <h2>ÜYE OL </h2>
                              </div>
                              <div>
                                   <div class="form-group">
                                        <form action="#" method="get">
                                             <input type="email" class="form-control" placeholder="mail adresinizi girin" name="email" id="email" required>
                                             <input type="submit" class="form-control" name="submit" id="form-submit" value="GÖNDER">
                                        </form>
                                        <span><sup>*</sup>  e-postanıza olumsuz posta (spam) göndermiyoruz.</span>
                                   </div>
                              </div>
                         </div>
                    </div>
                    
               </div>
          </div>
     </footer>