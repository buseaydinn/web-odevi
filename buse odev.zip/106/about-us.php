<?php include 'inc/head.php';?>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>
               
          </div>
     </section>
<?php include 'inc/menu.php';?>

     <section>
          <div class="container">
               <div class="text-center">
                    <h1>HAKKIMIZDA</h1>

                    <br>

                    <p class="lead">BU SAYFA HAKKIMIZDA OLAN BİLGİLERİ İÇERİR </p>
               </div>
          </div>
     </section>

     <section class="section-background">
          <div class="container">
               <div class="row">
                    <div class="col-md-offset-1 col-md-4 col-xs-12 pull-right">
                         <img src="assets/images/8QYxPlI2nLrNsOi1jBNAzTophWKJ28yeKImVGRwt.webp" class="img-responsive img-circle" alt="">
                    </div>

                    <div class="col-md-7 col-xs-12">
                         <div class="about-info">
                             

                              <figure>
                                   <figcaption>
                                        <p>"Merhaba! Biz, Otomobil Dünyası, otomobil satışına adanmış bir platformuz. Tüketiciye güvenilir, kaliteli ve uygun fiyatlı otomobiller sunmayı hedefleyen bir ekip olarak faaliyet gösteriyoruz.

                                             Amaç, araç alımı yapmak isteyen herkesin elindeki uygun araçları bulmaya yardımcı olmaktır. Geniş bir otomobil yelpazesi sunarak farklı marka, model, fiyat aralığı ve ulaşım sahip araçlarına göre sunmaktayız. İster yeni ister ikinci el olsun, her türlü bütçeye ve tercihe uygun araç seçenekleri sunmaktan gurur duyacağız.
                                             
                                             Otomobil Dünyası olarak, müşteri ziyareti en üst düzeyde tutulmaya özen gösteriyoruz. Her kurtarma ihtiyacını anlamak, karşılamak ve mümkün olan en iyi hizmeti sunmak için çalışıyoruz. Muhafızların güvenini kazanmak için şeffaf bir iş yapma benim ilkelerim, tüm detayların ayrıntılı, akraba ve geçmiş kayıtlarını sunuyoruz. Böylece bakım araçları hakkında güvenilir ve doğru bilgilere sahip olabilirler. </p>

                                    
                                   </figcaption>
                              </figure>
                         </div>
                    </div>
               </div>
          </div>
     </section>

     <section>
          <div class="container">
               <div class="row">
                    <div class="col-md-4 col-xs-12">
                         <img src="assets/images/8QYxPlI2nLrNsOi1jBNAzTophWKJ28yeKImVGRwt.webp" class="img-responsive img-circle" alt="">
                    </div>

                    <div class="col-md-offset-1 col-md-7 col-xs-12">
                         <div class="about-info">
                             

                              <figure>
                                   <figcaption>
                                       

                                        <p>Ekibimiz, insani otomobil uzun yıllara dayanan deneyime sahip profesyonellerden oluşur. Her aracı değerlendiren, teknik kontrollerini yapan ve düzenli bir şekilde teslim etmek için özen gösteririz. Ayrıca, satın alma alma süresinin uzunluğunu finanse etme seçenekleri, sigorta hizmetleri ve garanti paketleri gibi ek hizmetleri sunarak onları kolayca elde etmekteyiz.

                                             Otomobil Dünyası, ömür boyu tecrübeyi azaltmak için modern bir online platform sunmaktadır. Kullanıcı dostu arayüzümüz sayesinde tüketim, istedikleri marka, model, bütçe ve diğer parametrelere göre yapabilir ve aradıkları araçları hızlı bir şekilde alabilirler. Ayrıca, ayrıntılı özellikler, teknik bilgiler ve resimlerle birlikte her bir aracı açıklamasını sunarak hizmet kartı bir karar vermeye yardımcı olmaktayız.
                                             
                                             </p>
                                   </figcaption>
                              </figure>
                         </div>
                    </div>
               </div>
          </div>
     </section>

     <section class="section-background">
          <div class="container">
               <div class="row">
                    <div class="col-md-12 col-sm-12">
                         <div class="text-center">
                              <h2>SİZİN GÜVENLİĞİNİZ VE MUTLULUĞUNUZ BİZİM İÇİN EN ÖNEMLİ FAKTÖR BUSE ARABACILIK SAĞLIKLI GÜNLER DİLER BİZİ TERCİH ETTİĞİNİZ İÇİN TEŞEKKÜRLER</h2>

                              <br>

                             
                    </div>
               </div>
          </div>
     </section>
     <?php include 'inc/footer.php';?>
<?php include 'inc/js.php';?>

</body>
</html>