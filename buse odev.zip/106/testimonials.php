<?php include 'inc/head.php';?>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>
               
          </div>
     </section>
<?php include 'inc/menu.php';?>

     <section>
          <div class="container">
               <div class="text-center">
                    <h1>SİZİN GÖRÜŞLERİNİZ</h1>

                    <br>

                    <p class="lead">BU SAYFA SİZİN GÖRÜŞLERİNİZİ İÇERİR.</p>
               </div>
          </div>
     </section>

     <!-- TESTIMONIAL -->
     <section id="testimonial" class="section-background">
          <div class="container">
               <div class="row">
                    <div class="col-sm-4 col-xs-12">
                         <div class="item">
                              <div class="tst-image">
                                   <img src="assets/images/vesikalık-fotoğraf-nasıl-yapılır-5.jpg" class="img-responsive" alt="">
                              </div>
                              <div class="tst-author">
                                   <h4>SELİM</h4>
                                   <span>Yazılım geliştirici</span>
                              </div>
                              <p>Diğer sitelerde ayıran bir diğer özellik ise herkes ile tek tek ilgeniyorlar</p>
                              <div class="tst-rating">
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                              </div>
                         </div>
                    </div>

                    <div class="col-sm-4 col-xs-12">
                         <div class="item">
                              <div class="tst-image">
                                   <img src="assets/images/pasaport.jpg" class="img-responsive" alt="">
                              </div>
                              <div class="tst-author">
                                   <h4>VEFA </h4>
                                   <span>AVUKAT</span>
                              </div>
                              <p>Memun kaldım tek sıkıntı biraz pahalı.</p>
                              <div class="tst-rating">
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                              </div>
                         </div>
                    </div>

                    <div class="col-sm-4 col-xs-12">
                         <div class="item">
                              <div class="tst-image">
                                   <img src="assets/images/biyometrikkkkk.jpg" class="img-responsive" alt="">
                              </div>
                              <div class="tst-author">
                                   <h4>SERPİL</h4>
                                   <span>HEMŞİRE</span>
                              </div>
                              <p>Genç girişimcilerden oluşan oluşan bir ekip çok memnun kaldım.</p>
                              <div class="tst-rating">
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                              </div>
                         </div>
                    </div>
               </div>
               
               <div class="row">
                    <div class="col-sm-4 col-xs-12">
                         <div class="item">
                              <div class="tst-image">
                                   <img src="assets/images/canan.jpg" class="img-responsive" alt="">
                              </div>
                              <div class="tst-author">
                                   <h4>CANAN</h4>
                                   <span>MÜHENDİS</span>
                              </div>
                              <p>Memnun kaldım çevreme tavsiye edicem.</p>
                              <div class="tst-rating">
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                              </div>
                         </div>
                    </div>

                    <div class="col-sm-4 col-xs-12">
                         <div class="item">
                              <div class="tst-image">
                                   <img src="assets/images/schengen.jpg" class="img-responsive" alt="">
                              </div>
                              <div class="tst-author">
                                   <h4>KERİM</h4>
                                   <span>SOFÖR</span>
                              </div>
                              <p>Ben ön yargılı yaklaştım ama memnun kaldım </p>
                              <div class="tst-rating">
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                              </div>
                         </div>
                    </div>

                    <div class="col-sm-4 col-xs-12">
                         <div class="item">
                              <div class="tst-image">
                                   <img src="assets/images/buseeeeeeeeeeeeeeee.jpg" class="img-responsive" alt="">
                              </div>
                              <div class="tst-author">
                                   <h4>HATİCE</h4>
                                   <span>RESSAM</span>
                              </div>
                              <p>Beğenmedim malesef çok pahalı tavsiye etmem</p>
                              <div class="tst-rating">
                                   <i class="fa fa-star"></i>
                                  
                              </div>
                         </div>
                    </div>
               </div>
          </div>
     </section> 
     <?php include 'inc/footer.php';?>
<?php include 'inc/js.php';?>

</body>
</html>