<?php include 'inc/head.php';?>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>
               
          </div>
     </section>
<?php include 'inc/menu.php';?>
     <section>
          <div class="container">
               <div class="text-center">
                    <h1>ŞARTLAR</h1>

                    <br>

                    <p class="lead">BU SAYFA ŞARTLARIMIZI İÇERİR.</p>
               </div>
          </div>
     </section>

     <section class="section-background">
          <div class="container">
               <div class="about-info">
                    <h2>Rezervasyon ve Kiralama Süreci </h2>

                    <figure>
                         <figcaption>
                      
                              
                    <p>Araba hizmetlerinden faydalanmak isteyen yolcular, rezervasyon yapmak için web sayfalarında bulunan rezervasyonları kiralamayı doldurmalıdır.Rezervasyon talebi, işletimde mevcutluğuna ve kiralama süresine bağlı olarak onaylanabilir veya reddedilebilir.
                         Kiralama işleminin sona ermesi, işletme aracının teslimat tarihinde ve saatinde hazır hale getirilmesi sağlamalıdır. Kiralama süresi boyunca, araç belirtilen teslim tarihinde ve saatinde geri teslim edilmelidir.</p>
                         </figcaption>
                    </figure>

                    <figure>
                         <figcaption>
                              <h3>Araç Kiralama Koşulları </h3>
                              <p>Araç kiralamak için geçerli bir sürücü belgesine sahip olmanız gerekmektedir. Sürücü belgesinin süresi ve geçerlilik koşulları, ilgili ülkenin trafik kurallarına uygun olmalıdır.
                                   Araçları sadece kiralama süresi boyunca kullanımlarına uygun bir şekilde kullanabilirsiniz. Trafik kuralları yapıları ve aracı herhangi bir zarara uğratmamak sizin korumanızdandır.
                                   Kiraladığınız araç, sadece sizin tarafınızdan kullanılmalıdır. Başka bir kişi veya sürücüye aracı kiralamak kesinlikle yasaktır</p>

                            
                         </figcaption>
                    </figure>

                    <figure>
                         <figcaption>
                              <h3>Sigorta ve Hasar.</h3>
                              <p>Araç kiralama ücretine genellikle bir sigorta paketi dahildir. Bu sigorta, çeşitli bölümler araç hasarını ve koruyucu koruyucu. Sigorta kapsamı ve detayları, kiralama bedeli bildirilecektir.
                                   Herhangi bir kaza, hasar veya arıza durumunda, derhal bize bildirmeniz gerekmektedir. Olay yerinde polis raporu incelemesi ve tüm ayrıntıları kaydetmeniz önemlidir. Sigorta şirketiyle işbirliği yaparak organların binalarına yardımcı oluyorum.</p>

                         </figcaption>
                    </figure>

                    <figure>
                         <figcaption>
                              <h3>iptal ve iade.</h3>
                              <p>Rezervasyonunuzu iptal etmek isterseniz, en az 24 saat öncesinden bize bildirmeniz gerekmektedir. İptal bildirimi yapılmadan yapılan iptallerde ücretlendirme yapılmaz.
                                   İptal süresine uyulması durumunda, ödeme yaptığınız tutarların tamamı size iade edilecektir.</p>

                         </figcaption>
                    </figure>

                  

                   
                   
               </div>
          </div>
     </section>

     <?php include 'inc/footer.php';?>
<?php include 'inc/js.php';?>

</body>
</html>