<?php include 'inc/head.php';?>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>
               
          </div>
     </section>


<?php include 'inc/menu.php';?>

     <section>
          <div class="container">
               <div class="text-center">
                    <h1>BİZE ULAŞIN</h1>

                    <br>

                    <p class="lead">BU SAYFA KİRALIK ARABALARIMIZI İÇERİR.</p>
               </div>
          </div>
     </section>


     <!-- CONTACT -->
     <section id="contact">
          <div class="container">
               <div class="row">

                    <div class="col-md-6 col-sm-12">
                         <form id="contact-form" role="form" action="" method="post">
                              <div class="col-md-12 col-sm-12">
                                   <input type="text" class="form-control" placeholder="AD SOYAD" name="name" required>
                    
                                   <input type="email" class="form-control" placeholder="MAİL ADRESİNİZİ GİRİN" name="email" required>

                                   <textarea class="form-control" rows="6" placeholder="MESAJINIZI BU BÖLÜME YAZIN" name="message" required></textarea>
                              </div>

                              <div class="col-md-4 col-sm-12">
                                   <input type="submit" class="form-control" name="GÖNDER" value="GÖNDER">
                              </div>

                         </form>
                    </div>

                    <div class="col-md-6 col-sm-12">
                         <div class="contact-image">
                              <img src="assets/images/Adsiz-400-×-600-piksel-600-×-400-piksel.png" class="img-responsive" alt="">
                         </div>
                    </div>

               </div>
          </div>
     </section>       
     <?php include 'inc/footer.php';?>
<?php include 'inc/js.php';?>

</body>
</html>